"""FileBot unit tests."""
