"""Compact desktop UI."""
