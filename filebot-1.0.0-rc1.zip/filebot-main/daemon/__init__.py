"""Lightweight background services."""
