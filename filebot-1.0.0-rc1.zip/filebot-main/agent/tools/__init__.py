"""FileBot tool implementations."""
