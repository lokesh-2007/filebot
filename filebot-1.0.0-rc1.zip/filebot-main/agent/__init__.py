"""Lazy-loaded assistant runtime."""
